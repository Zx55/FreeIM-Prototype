import {
    MsgType,
    IMsg,
    makeEncodedMsg,
    decodeMsg,
} from './msg';

interface CountedMsg {

}

const _emitMsg = (socket: SocketIOClient.Socket, )

export const emitMsg = (socket: SocketIOClient.Socket, msg: IMsg) => {
    let done = false;
    do {
        socket.emit('sendMsg', makeEncodedMsg(msg), (encodedAckMsg: Uint8Array) =>
            done = decodeMsg(encodedAckMsg).head.msgType === MsgType.MSG_SERVER_ACK
        )
    } while (!done);
}